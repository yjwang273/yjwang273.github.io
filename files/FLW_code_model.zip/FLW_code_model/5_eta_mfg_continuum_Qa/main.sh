#! /bin/bash
#
gfortran -c -Wall main.f90 -fopenmp -ffree-line-length-none -Wno-unused -fimplicit-none -Wall -fcheck=bound,do -ffpe-trap=invalid,zero,overflow -I/usr/local/include/
if [ $? -ne 0 ]; then
  echo "Compile error."
  exit
fi

gfortran -o main.out main.o -fopenmp $HOME/library/asa239.o /usr/local/include/toolbox.o
if [ $? -ne 0 ]; then
  echo "Load error."
  exit
fi

./main.out
if [ $? -ne 0 ]; then
  echo "Run error."
  exit
fi
echo "Normal end of execution."
