%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Model Replication Code
%
% Paper:
%   Firooz, Hamid, Zheng Liu, and Yajie Wang,
%   "Automation and the Rise of Superstar Firms,"
%   Journal of Monetary Economics (2025), Article 103733.
%
% First created: May 20, 2021
% Last updated:  April 27, 2025
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


close all
clear;
clc;

format compact
    
% Parameters

% Plot options
lwidth = 1.5;
circle_size = 20;
font_size = 13;
color_3z = ['b','k','r'];
color2 = ['k','r'];
linS = {'-','-.','o'}; % line style

% the benchmark level of Q_a
folder_Qa = '../1_eta_mfg';
xx_Qa = load(fullfile(folder_Qa,'Q_a.out'));
Qa_init = xx_Qa/0.6; % the initial Qa (Qa=0.6*Qa_init)

%% Read data
% grids
Q_a_grid = load('Q_a_grid.out');
NQ_a = size(Q_a_grid);
Q_a_grid = reshape(Q_a_grid,[NQ_a,1]);
% results
Q_a_r_a = load('Q_a_r_a.out');
Q_a_r_a = reshape(Q_a_r_a,[NQ_a,1]);
Q_a_WW = load('Q_a_WW.out');
Q_a_WW = reshape(Q_a_WW,[NQ_a,1]);
Q_a_YY = load('Q_a_YY.out');
Q_a_YY = reshape(Q_a_YY,[NQ_a,1]);
Q_a_AA = load('Q_a_AA.out');
Q_a_AA = reshape(Q_a_AA,[NQ_a,1]);
Q_a_NN = load('Q_a_NN.out');
Q_a_NN = reshape(Q_a_NN,[NQ_a,1]);
Q_a_CC = load('Q_a_CC.out');
Q_a_CC = reshape(Q_a_CC,[NQ_a,1]);
Q_a_II = load('Q_a_II.out');
Q_a_II = reshape(Q_a_II,[NQ_a,1]);
Q_a_LS = load('Q_a_LS.out');
Q_a_LS = reshape(Q_a_LS,[NQ_a,1]);
Q_a_share_top1 = load('Q_a_share_top1.out');
Q_a_share_top1 = reshape(Q_a_share_top1,[NQ_a,1]);
Q_a_share_top1_emp = load('Q_a_share_top1_emp.out');
Q_a_share_top1_emp = reshape(Q_a_share_top1_emp,[NQ_a,1]);
Q_a_share_auto = load('Q_a_share_auto.out');
Q_a_share_auto = reshape(Q_a_share_auto,[NQ_a,1]);
Q_a_markup_sw = load('Q_a_markup_sw.out');
Q_a_markup_sw = reshape(Q_a_markup_sw,[NQ_a,1]);
Q_a_markup_cw = load('Q_a_markup_cw.out');
Q_a_markup_cw = reshape(Q_a_markup_cw,[NQ_a,1]);
Q_a_markup_disp = load('Q_a_markup_disp.out');
Q_a_markup_disp = reshape(Q_a_markup_disp,[NQ_a,1]);
Q_a_error_YY = load('Q_a_error_YY.out');
Q_a_error_YY = reshape(Q_a_error_YY,[NQ_a,1]);
Q_a_error_WW = load('Q_a_error_WW.out');
Q_a_error_WW = reshape(Q_a_error_WW,[NQ_a,1]);
Q_a_error_q = load('Q_a_error_q.out');
Q_a_error_q = reshape(Q_a_error_q,[NQ_a,1]);


%% plot aggregate variables for the paper
% only draw the points without erros
error_sum = Q_a_error_YY + Q_a_error_WW + Q_a_error_q;
I = error_sum == 0;
% plot
close;
width = 600*2/3;
figure('Position', [0, 0, width*1.7, width*1.0]);
% Q_a_share_auto
subplot(2,3,1);
hold on;
plot(Q_a_grid(I),Q_a_share_auto(I),'-','Color','black','LineWidth',lwidth);
xline(xx_Qa,'blue');
title("fraction of firms that automate",'FontSize',font_size,'Interpreter','latex');
xlabel("$Q_a$",'Interpreter','latex');
xlim([min(Q_a_grid(I)),max(Q_a_grid(I))]); 
grid on;
hold off;
% Q_a_share_top1
subplot(2,3,2);
hold on;
plot(Q_a_grid(I),Q_a_share_top1(I),'-','Color','black','LineWidth',lwidth);
plot(Q_a_grid(I),Q_a_share_top1_emp(I),'--','Color','red','LineWidth',lwidth);
xline(xx_Qa,'blue');
lgnd=legend('sales','employment','Interpreter','latex','Location','northeast');
set(lgnd,'Interpreter','latex','FontSize',font_size);
title("share of top 1\% firms",'FontSize',font_size,'Interpreter','latex');
xlabel("$Q_a$",'Interpreter','latex');
xlim([min(Q_a_grid(I)),max(Q_a_grid(I))]); 
ylim([0.24,0.37]);
grid on;
hold off;
% Q_a_LS
subplot(2,3,3);
hold on;
plot(Q_a_grid(I),Q_a_LS(I),'-','Color','black','LineWidth',lwidth);
xline(xx_Qa,'blue');
title("labor share",'FontSize',font_size,'Interpreter','latex');
xlabel("$Q_a$",'Interpreter','latex');
xlim([min(Q_a_grid(I)),max(Q_a_grid(I))]); 
grid on;
hold off;
% Q_a_markup_sw & Q_a_markup_cw
subplot(2,3,4);
hold on;
plot(Q_a_grid(I),Q_a_markup_sw(I),'-','Color','black','LineWidth',lwidth);
plot(Q_a_grid(I),Q_a_markup_cw(I),'--','Color','red','LineWidth',lwidth);
xline(xx_Qa,'blue');
lgnd=legend('sales-weighted','cost-weighted');
set(lgnd,'Interpreter','latex','FontSize',font_size);
title("average markup",'FontSize',font_size,'Interpreter','latex');
xlabel("$Q_a$",'Interpreter','latex');
xlim([min(Q_a_grid(I)),max(Q_a_grid(I))]); 
ylim([1.15,1.185]);
grid on;
hold off;
% Q_a_WW
subplot(2,3,5);
hold on;
plot(Q_a_grid(I),Q_a_WW(I),'-','Color','black','LineWidth',lwidth);
xline(xx_Qa,'blue');
title("wage",'FontSize',font_size,'Interpreter','latex');
xlabel("$Q_a$",'Interpreter','latex');
xlim([min(Q_a_grid(I)),max(Q_a_grid(I))]); 
grid on;
hold off;
% Q_a_NN
subplot(2,3,6);
hold on;
plot(Q_a_grid(I),Q_a_NN(I),'-','Color','black','LineWidth',lwidth);
xline(xx_Qa,'blue');
title("employment",'FontSize',font_size,'Interpreter','latex');
xlabel("$Q_a$",'Interpreter','latex');
xlim([min(Q_a_grid(I)),max(Q_a_grid(I))]); 
grid on;
hold off;
% save
exportgraphics(gcf,'Q_a_moments_paper.png','Resolution',300);
close;
