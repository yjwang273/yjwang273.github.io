%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Model Replication Code
%
% Paper:
%   Firooz, Hamid, Zheng Liu, and Yajie Wang,
%   "Automation and the Rise of Superstar Firms,"
%   Journal of Monetary Economics (2025), Article 103733.
%
% First created: May 20, 2021
% Last updated:  April 27, 2025
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

close all
clear;
clc;

format compact
    
% Parameters

% Plot options
lwidth = 1.5;
circle_size = 20;
font_size = 13;
color_3z = ['b','k','r'];
color2 = ['k','r'];
linS = {'-','-.','o'}; % line style

%% Read data
% exogenous
path_Q_a = load('path_Q_a.out');
NT = size(path_Q_a);
path_Q_a = reshape(path_Q_a,[NT,1]);
time = 1:NT(2); % x axis
% guess
path_SDFs = load('path_SDFs.out');
path_SDFs = reshape(path_SDFs,[NT,1]);
path_YY = load('path_YY.out');
path_YY = reshape(path_YY,[NT,1]);
path_SDFs_guess = load('path_SDFs_guess.out');
path_SDFs_guess = reshape(path_SDFs_guess,[NT,1]);
path_YY_guess = load('path_YY_guess.out');
path_YY_guess = reshape(path_YY_guess,[NT,1]);
% results
path_AA = load('path_AA.out');
path_AA = reshape(path_AA,[NT,1]);
path_r_a = load('path_r_a.out');
path_r_a = reshape(path_r_a,[NT,1]);
path_WW = load('path_WW.out');
path_WW = reshape(path_WW,[NT,1]);
path_NN = load('path_NN.out');
path_NN = reshape(path_NN,[NT,1]);
path_CC = load('path_CC.out');
path_CC = reshape(path_CC,[NT,1]);
path_II = load('path_II.out');
path_II = reshape(path_II,[NT,1]);
path_LS = load('path_LS.out');
path_LS = reshape(path_LS,[NT,1]);
path_share_top1 = load('path_share_top1.out');
path_share_top1 = reshape(path_share_top1,[NT,1]);
path_share_top1_emp = load('path_share_top1_emp.out');
path_share_top1_emp = reshape(path_share_top1_emp,[NT,1]);
path_share_auto = load('path_share_auto.out');
path_share_auto = reshape(path_share_auto,[NT,1]);
path_markup_sw = load('path_markup_sw.out');
path_markup_sw = reshape(path_markup_sw,[NT,1]);
path_markup_cw = load('path_markup_cw.out');
path_markup_cw = reshape(path_markup_cw,[NT,1]);
path_markup_disp = load('path_markup_disp.out');
path_markup_disp = reshape(path_markup_disp,[NT,1]);
path_error_YY = load('path_error_YY.out');
path_error_YY = reshape(path_error_YY,[NT,1]);
path_error_WW = load('path_error_WW.out');
path_error_WW = reshape(path_error_WW,[NT,1]);
path_error_q = load('path_error_q.out');
path_error_q = reshape(path_error_q,[NT,1]);
path_TT = load('path_TT.out');
path_TT = reshape(path_TT,[NT,1]);
path_LP = load('path_LP.out');
path_LP = reshape(path_LP,[NT,1]);
path_wel = load('path_wel.out');
path_wel = reshape(path_wel,[NT,1]);
path_U = load('path_U.out');
path_U = reshape(path_U,[NT,1]);
path_wel_consum = load('path_wel_consum.out');
path_wel_consum = reshape(path_wel_consum,[NT,1]);


%% plot for the paper (9 panels)
NT_cut = 40;
% only draw the points without erros
error_sum = path_error_YY + path_error_WW + path_error_q;
I = error_sum == 0;
I(NT_cut+1:end) = 0; % will not draw for t>NT_cut
% plot
close;
width = 600*2/3;
figure('Position', [0, 0, width*1.7, width*1.5]);
% path_Q_a
subplot(3,3,1);
hold on;
plot(time(I),path_Q_a(I),'-','Color','black','LineWidth',lwidth);
yline(path_Q_a(1), '-', 'Color', 'blue', 'LineWidth', lwidth-1); % Adding the horizontal line
title("$Q_a$",'FontSize',font_size,'Interpreter','latex');
xlabel("quarters",'Interpreter','latex');
xlim([min(time(I)),max(max(time(I)),min(time(I))+0.0001)]);  
ylim([40,90]);  
grid on;
hold off;
% path_YY
subplot(3,3,2);
hold on;
plot(time(I),path_YY(I),'-','Color','black','LineWidth',lwidth);
yline(path_YY(1), '-', 'Color', 'blue', 'LineWidth', lwidth-1); % Adding the horizontal line
title("output",'FontSize',font_size,'Interpreter','latex');
xlabel("quarters",'Interpreter','latex');
xlim([min(time(I)),max(max(time(I)),min(time(I))+0.0001)]);  
grid on;
hold off;
% path_NN
subplot(3,3,3);
hold on;
plot(time(I),path_NN(I),'-','Color','black','LineWidth',lwidth);
yline(path_NN(1), '-', 'Color', 'blue', 'LineWidth', lwidth-1); % Adding the horizontal line
title("employment",'FontSize',font_size,'Interpreter','latex');
xlabel("quarters",'Interpreter','latex');
xlim([min(time(I)),max(max(time(I)),min(time(I))+0.0001)]);  
grid on;
hold off;
% path_II
subplot(3,3,4);
hold on;
plot(time(I),path_II(I),'-','Color','black','LineWidth',lwidth);
yline(path_II(1), '-', 'Color', 'blue', 'LineWidth', lwidth-1); % Adding the horizontal line
title("investment",'FontSize',font_size,'Interpreter','latex');
xlabel("quarters",'Interpreter','latex');
xlim([min(time(I)),max(max(time(I)),min(time(I))+0.0001)]);  
grid on;
hold off;
% path_share_auto
subplot(3,3,5);
hold on;
plot(time(I),path_share_auto(I),'-','Color','black','LineWidth',lwidth);
yline(path_share_auto(1), '-', 'Color', 'blue', 'LineWidth', lwidth-1); % Adding the horizontal line
title("fraction of firms that automate",'FontSize',font_size,'Interpreter','latex');
xlabel("quarters",'Interpreter','latex');
xlim([min(time(I)),max(max(time(I)),min(time(I))+0.0001)]);  
grid on;
hold off;
% YY/NN: labor productivity
subplot(3,3,6);
hold on;
plot(time(I),path_LP(I),'-','Color','black','LineWidth',lwidth);
yline(path_LP(1), '-', 'Color', 'blue', 'LineWidth', lwidth-1); % Adding the horizontal line
title("labor productivity",'FontSize',font_size,'Interpreter','latex');
xlabel("quarters",'Interpreter','latex');
xlim([min(time(I)),max(max(time(I)),min(time(I))+0.0001)]);  
grid on;
hold off;
% path_share_top1
subplot(3,3,7);
hold on;
plot(time(I),path_share_top1(I),'-','Color','black','LineWidth',lwidth);
plot(time(I),path_share_top1_emp(I),'--','Color','red','LineWidth',lwidth);
lgnd=legend('sales','employment','FontSize',font_size,'Interpreter','latex','Location','northwest');
yline(path_share_top1(1), '-', 'Color', 'blue', 'LineWidth', lwidth-1,'HandleVisibility','off'); % Adding the horizontal line
yline(path_share_top1_emp(1), '-', 'Color', 'blue', 'LineWidth', lwidth-1,'HandleVisibility','off'); % Adding the horizontal line
set(lgnd,'color','white');
title("share of top 1\% firms",'FontSize',font_size,'Interpreter','latex');
xlabel("quarters",'Interpreter','latex');
xlim([min(time(I)),max(max(time(I)),min(time(I))+0.0001)]);  
ylim([0.245,0.295]);  
grid on;
hold off;
% path_markup_sw & path_markup_cw
subplot(3,3,8);
hold on;
plot(time(I),path_markup_sw(I),'-','Color','black','LineWidth',lwidth);
plot(time(I),path_markup_cw(I),'--','Color','red','LineWidth',lwidth);
lgnd=legend('sales-weighted','cost-weighted','FontSize',font_size,'Interpreter','latex','Location','northwest');
yline(path_markup_sw(1), '-', 'Color', 'blue', 'LineWidth', lwidth-1,'HandleVisibility','off'); % Adding the horizontal line
yline(path_markup_cw(1), '-', 'Color', 'blue', 'LineWidth', lwidth-1,'HandleVisibility','off'); % Adding the horizontal line
set(lgnd,'color','white');
title("average markup",'FontSize',font_size,'Interpreter','latex');
xlabel("quarters",'Interpreter','latex');
xlim([min(time(I)),max(max(time(I)),min(time(I))+0.0001)]);  
ylim([1.152,1.159]);  
grid on;
hold off;
% path_LS
subplot(3,3,9);
hold on;
plot(time(I),path_LS(I),'-','Color','black','LineWidth',lwidth);
yline(path_LS(1), '-', 'Color', 'blue', 'LineWidth', lwidth-1); % Adding the horizontal line
title("labor shares",'FontSize',font_size,'Interpreter','latex');
xlabel("quarters",'Interpreter','latex');
xlim([min(time(I)),max(max(time(I)),min(time(I))+0.0001)]);  
grid on;
hold off;
% save
exportgraphics(gcf,'path_moments_paper.png','Resolution',800);
close;

