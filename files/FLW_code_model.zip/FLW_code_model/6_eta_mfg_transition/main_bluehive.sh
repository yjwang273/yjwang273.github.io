#! /bin/bash
#
module load gcc/11.2.0 # use the new version to genereate random numbers

gfortran main.f90 -o main.out -O3 -fopenmp -ffree-line-length-none -Wno-unused -fimplicit-none -Wall -fcheck=bound,do -ffpe-trap=invalid,zero,overflow
./main.out
