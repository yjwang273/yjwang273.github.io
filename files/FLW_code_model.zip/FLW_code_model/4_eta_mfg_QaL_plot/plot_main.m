%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Model Replication Code
%
% Paper:
%   Firooz, Hamid, Zheng Liu, and Yajie Wang,
%   "Automation and the Rise of Superstar Firms,"
%   Journal of Monetary Economics (2025), Article 103733.
%
% First created: May 20, 2021
% Last updated:  April 27, 2025
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


close all
clear;
clc;

format compact
    
% Parameters

% Plot options
lwidth = 1.5;
circle_size = 20;
font_size = 13;
%xlim1 = min(xval);
%xlim2 = max(xval);
color_3x = ['r','k','b'];
linS = {'--','-','-.'}; % line style


% folders
folder_xL = '../3_eta_mfg_QaL';
folder_xM = '../1_eta_mfg';
folders = {folder_xL,folder_xM};

%% Read common data
% parameters
NZ = load(fullfile(folder_xM,'NZ.out'));
beta = load(fullfile(folder_xM,'beta.out'));
% grids
z_grid = load(fullfile(folder_xM,'z_grid.out'));
z_grid = reshape(z_grid,[NZ,1]);
g_z = load(fullfile(folder_xM,'g_z.out'));
g_z = reshape(g_z,[NZ,1]);

%% Read different data
% firm-level varaibles
a_prob = {zeros(NZ,1),zeros(NZ,1)};
for k = 1:numel(a_prob)
    a_prob{k} = load(fullfile(folders{k},'a_prob.out'));
    a_prob{k} = reshape(a_prob{k},[NZ,1]);
end
lambdaj_AN = {zeros(NZ,1),zeros(NZ,1)};
for k = 1:numel(lambdaj_AN)
    lambdaj_AN{k} = load(fullfile(folders{k},'lambdaj_AN.out'));
    lambdaj_AN{k} = reshape(lambdaj_AN{k},[NZ,1]);
end
lambdaj_N = {zeros(NZ,1),zeros(NZ,1)};
for k = 1:numel(lambdaj_N)
    lambdaj_N{k} = load(fullfile(folders{k},'lambdaj_N.out'));
    lambdaj_N{k} = reshape(lambdaj_N{k},[NZ,1]);
end
qj_AN = {zeros(NZ,1),zeros(NZ,1)};
for k = 1:numel(qj_AN)
    qj_AN{k} = load(fullfile(folders{k},'qj_AN.out'));
    qj_AN{k} = reshape(qj_AN{k},[NZ,1]);
end
qj_N = {zeros(NZ,1),zeros(NZ,1)};
for k = 1:numel(qj_N)
    qj_N{k} = load(fullfile(folders{k},'qj_N.out'));
    qj_N{k} = reshape(qj_N{k},[NZ,1]);
end
yj_AN = {zeros(NZ,1),zeros(NZ,1)};
for k = 1:numel(yj_AN)
    yj_AN{k} = load(fullfile(folders{k},'yj_AN.out'));
    yj_AN{k} = reshape(yj_AN{k},[NZ,1]);
end
yj_N = {zeros(NZ,1),zeros(NZ,1)};
for k = 1:numel(yj_N)
    yj_N{k} = load(fullfile(folders{k},'yj_N.out'));
    yj_N{k} = reshape(yj_N{k},[NZ,1]);
end
Aj_AN = {zeros(NZ,1),zeros(NZ,1)};
for k = 1:numel(Aj_AN)
    Aj_AN{k} = load(fullfile(folders{k},'Aj_AN.out'));
    Aj_AN{k} = reshape(Aj_AN{k},[NZ,1]);
end
Nj_AN = {zeros(1,1),zeros(1,1)};
for k = 1:numel(Nj_AN)
    Nj_AN{k} = load(fullfile(folders{k},'Nj_AN.out'));
end
Nj_N = {zeros(1,1),zeros(1,1)};
for k = 1:numel(Nj_N)
    Nj_N{k} = load(fullfile(folders{k},'Nj_N.out'));
end
muj_AN = {zeros(NZ,1),zeros(NZ,1)};
for k = 1:numel(muj_AN)
    muj_AN{k} = load(fullfile(folders{k},'muj_AN.out'));
    muj_AN{k} = reshape(muj_AN{k},[NZ,1]);
end
muj_N = {zeros(NZ,1),zeros(NZ,1)};
for k = 1:numel(muj_N)
    muj_N{k} = load(fullfile(folders{k},'muj_N.out'));
    muj_N{k} = reshape(muj_N{k},[NZ,1]);
end
pj_AN = {zeros(NZ,1),zeros(NZ,1)};
for k = 1:numel(pj_AN)
    pj_AN{k} = load(fullfile(folders{k},'pj_AN.out'));
    pj_AN{k} = reshape(pj_AN{k},[NZ,1]);
end
pj_N = {zeros(NZ,1),zeros(NZ,1)};
for k = 1:numel(pj_N)
    pj_N{k} = load(fullfile(folders{k},'pj_N.out'));
    pj_N{k} = reshape(pj_N{k},[NZ,1]);
end
profitj_AN = {zeros(NZ,1),zeros(NZ,1)};
for k = 1:numel(profitj_AN)
    profitj_AN{k} = load(fullfile(folders{k},'profitj_AN.out'));
    profitj_AN{k} = reshape(profitj_AN{k},[NZ,1]);
end
profitj_N = {zeros(NZ,1),zeros(NZ,1)};
for k = 1:numel(profitj_N)
    profitj_N{k} = load(fullfile(folders{k},'profitj_N.out'));
    profitj_N{k} = reshape(profitj_N{k},[NZ,1]);
end
lsj_AN = {zeros(NZ,1),zeros(NZ,1)};
for k = 1:numel(lsj_AN)
    lsj_AN{k} = load(fullfile(folders{k},'lsj_AN.out'));
    lsj_AN{k} = reshape(lsj_AN{k},[NZ,1]);
end
lsj_N = {zeros(NZ,1),zeros(NZ,1)};
for k = 1:numel(lsj_N)
    lsj_N{k} = load(fullfile(folders{k},'lsj_N.out'));
    lsj_N{k} = reshape(lsj_N{k},[NZ,1]);
end


%% plot firm-level variables for the paper
close;
width = 600;
figure('Position', [0, 0, width*1.3, width]);
% a_prob
subplot(3,3,1);
hold on;
for ix = 2:-1:1
    xval = z_grid;
    yval = a_prob{ix};
    plot(xval,yval,linS{ix},'Color',color_3x(ix),'LineWidth',lwidth);
end
lgnd=legend('benchmark $Q_a$','low $Q_a$',...
    'Interpreter','latex','Location','northwest');
set(lgnd,'color','none','FontSize',font_size);
title("automation probabilities",'Interpreter','latex','FontSize',font_size);
xlabel("\phi");
xlim([min(z_grid),max(z_grid)]);
grid on;
hold off;
% Nj_AN
subplot(3,3,2);
hold on;
for ix = 2:-1:1
    xval = z_grid;
    yval = Nj_AN{ix};
    plot(xval,yval,linS{ix},'Color',color_3x(ix),'LineWidth',lwidth);
end
lgnd=legend('benchmark $Q_a$','low $Q_a$',...
    'Interpreter','latex','Location','northwest');
set(lgnd,'color','none','FontSize',font_size);
title("$N(\phi)$ w/ robots",'Interpreter','latex','FontSize',font_size);
xlabel("\phi");
xlim([min(z_grid),max(z_grid)]);
grid on;
hold off;
% Nj_N
subplot(3,3,3);
hold on;
for ix = 2:-1:1
    xval = z_grid;
    yval = Nj_N{ix};
    plot(xval,yval,linS{ix},'Color',color_3x(ix),'LineWidth',lwidth);
end
lgnd=legend('benchmark $Q_a$','low $Q_a$',...
    'Interpreter','latex','Location','northwest');
set(lgnd,'color','none','FontSize',font_size);
title("$N(\phi)$ w/o robots",'Interpreter','latex','FontSize',font_size);
xlabel("\phi");
xlim([min(z_grid),max(z_grid)]);
grid on;
hold off;
% qj_AN
subplot(3,3,4);
hold on;
for ix = 2:-1:1
    xval = z_grid;
    yval = qj_AN{ix};
    plot(xval,yval,linS{ix},'Color',color_3x(ix),'LineWidth',lwidth);
end
lgnd=legend('benchmark $Q_a$','low $Q_a$',...
    'Interpreter','latex','Location','northwest');
set(lgnd,'color','none','FontSize',font_size);
title("$q(\phi)$ w/ robots",'Interpreter','latex','FontSize',font_size);
xlabel("\phi");
xlim([min(z_grid),max(z_grid)]);
ylim([0,100]);
grid on;
hold off;
% qj_N
subplot(3,3,5);
hold on;
for ix = 2:-1:1
    xval = z_grid;
    yval = qj_N{ix};
    plot(xval,yval,linS{ix},'Color',color_3x(ix),'LineWidth',lwidth);
end
lgnd=legend('benchmark $Q_a$','low $Q_a$',...
    'Interpreter','latex','Location','northwest');
set(lgnd,'color','none','FontSize',font_size);
title("$q(\phi)$ w/o robots",'Interpreter','latex','FontSize',font_size);
xlabel("\phi");
xlim([min(z_grid),max(z_grid)]);
ylim([0,100]);
grid on;
hold off;
% muj_AN
subplot(3,3,6);
hold on;
for ix = 2:-1:1
    xval = z_grid;
    yval = muj_AN{ix};
    plot(xval,yval,linS{ix},'Color',color_3x(ix),'LineWidth',lwidth);
end
lgnd=legend('benchmark $Q_a$','low $Q_a$',...
    'Interpreter','latex','Location','northwest');
set(lgnd,'color','none','FontSize',font_size);
title("markups w/ robots",'Interpreter','latex','FontSize',font_size);
xlabel("\phi");
xlim([min(z_grid),max(z_grid)]);
grid on;
hold off;
% muj_N
subplot(3,3,7);
hold on;
for ix = 2:-1:1
    xval = z_grid;
    yval = muj_N{ix};
    plot(xval,yval,linS{ix},'Color',color_3x(ix),'LineWidth',lwidth);
end
lgnd=legend('benchmark $Q_a$','low $Q_a$',...
    'Interpreter','latex','Location','northwest');
set(lgnd,'color','none','FontSize',font_size);
title("markups w/o robots",'Interpreter','latex','FontSize',font_size);
xlabel("\phi");
xlim([min(z_grid),max(z_grid)]);
grid on;
hold off;
% lsj_AN
subplot(3,3,8);
hold on;
for ix = 2:-1:1
    xval = z_grid;
    yval = lsj_AN{ix};
    plot(xval,yval,linS{ix},'Color',color_3x(ix),'LineWidth',lwidth);
end
lgnd=legend('benchmark $Q_a$','low $Q_a$',...
    'Interpreter','latex','Location','northeast');
set(lgnd,'color','none','FontSize',font_size);
title("labor shares w/ robots",'Interpreter','latex','FontSize',font_size);
xlabel("\phi");
xlim([min(z_grid),max(z_grid)]);
ylim([0.6,1]);
grid on;
hold off;
% lsj_N
subplot(3,3,9);
hold on;
for ix = 2:-1:1
    xval = z_grid;
    yval = lsj_N{ix};
    plot(xval,yval,linS{ix},'Color',color_3x(ix),'LineWidth',lwidth);
end
lgnd=legend('benchmark $Q_a$','low $Q_a$',...
    'Interpreter','latex','Location','southwest');
set(lgnd,'color','none','FontSize',font_size);
title("labor shares w/o robots",'Interpreter','latex','FontSize',font_size);
xlabel("\phi");
xlim([min(z_grid),max(z_grid)]);
ylim([0.6,1]);
grid on;
hold off;
% save
%saveas(gcf,'firm_vars_paper.png');
exportgraphics(gcf,'firm_vars_paper.png','Resolution',300);
close;


