%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Model Replication Code
%
% Paper:
%   Firooz, Hamid, Zheng Liu, and Yajie Wang,
%   "Automation and the Rise of Superstar Firms,"
%   Journal of Monetary Economics (2025), Article 103733.
%
% First created: May 20, 2021
% Last updated:  April 27, 2025
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

close all
clear;
clc;

format compact
    
% Parameters

% Plot options
lwidth = 1.5;
circle_size = 20;
font_size = 13;
color_3z = ['b','k','r'];
color2 = ['k','r'];
linS = {'-','-.','o'}; % line style

% the benchmark level of tau
xx_tau = 0;

% directory
folder_benchQa = '../8_robot_tax_continuum_tau_transition';
folder_lowerQa = '../9_robot_tax_continuum_tau_transition_lowerQa';


%% Read welfare data from all folders
% (a) lower Qa
load(fullfile(folder_lowerQa,'tau_grid_lowerQa.mat'));
tau_grid_lowerQa = tau_grid;
load(fullfile(folder_lowerQa,'tau_path_wel_consum_lowerQa.mat'));
tau_path_wel_consum_lowerQa = tau_path_wel_consum;
% (b) benchmark Qa
load(fullfile(folder_benchQa,'tau_grid.mat'));
load(fullfile(folder_benchQa,'tau_path_wel_consum.mat'));


%% plot the welfare graphs
% tau_path_wel_consum
close;
width = 230;
figure('Position', [0, 0, width*1.3, width]);
% tau_path_wel_consum
hold on;
plot(tau_grid*100,tau_path_wel_consum*100,'-','Color','black','LineWidth',lwidth);
plot(tau_grid_lowerQa*100,tau_path_wel_consum_lowerQa*100,'--','Color','red','LineWidth',lwidth);
lgnd=legend('benchmark $Q_a$','lower $Q_a$','Interpreter','latex','Location','northeast','FontSize',font_size);
set(lgnd,'color','white');
xline(xx_tau,'blue','HandleVisibility','off');
title("welfare gains",'FontSize',font_size,'Interpreter','latex','FontSize',font_size);
xlabel("robot tax $\tau$, (\%)",'Interpreter','latex','FontSize',font_size);
ylabel("\%",'Interpreter','latex','FontSize',font_size);
xlim([min(tau_grid*100),max(max(tau_grid*100),min(tau_grid*100)+0.0001*100)]);  
ylim([-0.8,1.01]);  
grid on;
hold off;
% save
exportgraphics(gcf,'tau_path_wel_consum_t2_2Qa.png','Resolution',300);
close;
