%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Model Replication Code
%
% Paper:
%   Firooz, Hamid, Zheng Liu, and Yajie Wang,
%   "Automation and the Rise of Superstar Firms,"
%   Journal of Monetary Economics (2025), Article 103733.
%
% First created: May 20, 2021
% Last updated:  April 27, 2025
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

close all
clear;
clc;

format compact
    
% Parameters

% Plot options
lwidth = 1.5;
circle_size = 20;
font_size = 13;
color_3z = ['b','k','r'];
color2 = ['k','r'];
linS = {'-','-.','o'}; % line style

% the benchmark level of tau
xx_tau = 0;

% Plot the first NT_cut period
NT_cut = 60;

% directory
folder_main = '.';
folder_1 = fullfile(folder_main,'8a_robot_tax_continuum_tau_transition_m0d01155');
folder_2 = fullfile(folder_main,'8b_robot_tax_continuum_tau_transition_m0d012tom0d0102');
folder_3 = fullfile(folder_main,'8c_robot_tax_continuum_tau_transition_m0d01tom0d0081');
folder_4 = fullfile(folder_main,'8d_robot_tax_continuum_tau_transition_m0d008tom0d0051');
folder_5 = fullfile(folder_main,'8e_robot_tax_continuum_tau_transition_m0d005to0d005');

% paramters
NT = load(fullfile(folder_1,'NT.out'));
time = 1:NT; % x axis

%% Read welfare data from all folders
% Define the list of folders and variable names to load and append
folders = {folder_1, folder_2, folder_3, folder_4, folder_5};
vars = {'Ntau', 'tau_grid', 'tau_error_converge', 'tau_path_wel', 'tau_path_wel_consum'};

% Load the initial variables from folder_1 and ensure compatibility
for i = 1:length(vars)
    filename = fullfile(folders{1}, [vars{i}, '.out']);
    eval([vars{i}, ' = load(filename);']);  % Load the variables into the workspace
    
    % If the variable is 'tau_path_wel' or 'tau_path_wel_consum', select the second element
    if strcmp(vars{i}, 'tau_path_wel') || strcmp(vars{i}, 'tau_path_wel_consum')
        eval([vars{i}, ' = ', vars{i}, '(2);']);
    end
    
    % Convert the variable to an array if it's a scalar (number)
    if isscalar(eval(vars{i}))
        eval([vars{i}, ' = ', vars{i}, ' * ones(1, 1);']);  % Convert to a 1x1 array
    end
end

% Loop through the remaining folders (2 to 5) and append the variables
for j = 2:length(folders)
    for i = 1:length(vars)
        % Construct the filename for the current folder and variable
        filename = fullfile(folders{j}, [vars{i}, '.out']);
        
        % Check if the file exists before loading
        if exist(filename, 'file')
            % Load the data from the current folder into a temporary variable
            eval([vars{i}, '_tmp = load(filename);']);
            
            % If the variable is 'tau_path_wel' or 'tau_path_wel_consum', reshape and select the second column
            if strcmp(vars{i}, 'tau_path_wel') || strcmp(vars{i}, 'tau_path_wel_consum')
                % Use Ntau(j) to dynamically determine the number of rows
                eval([vars{i}, '_tmp = reshape(', vars{i}, '_tmp, Ntau(j), NT);']);
                % Select only the second column
                eval([vars{i}, '_tmp = ', vars{i}, '_tmp(:, 2).'';']); % transpose
            end
            
            % Convert scalar to an array if necessary for consistency
            if isscalar(eval([vars{i}, '_tmp']))
                eval([vars{i}, '_tmp = ', vars{i}, '_tmp * ones(1, 1);']);  % Convert to a 1x1 array
            end
            
            % Ensure consistent dimensions for vertical concatenation
              
            
            % Append the data from the temporary variable to the original variable (vertically concatenate)
            eval([vars{i}, ' = [', vars{i}, ', ', vars{i}, '_tmp];']);
            %print(vars{i});
        else
            warning(['File not found: ', filename, ' in folder ', num2str(j)]);
        end
    end
end

% only keep the results with tau_error_converge == 0
Ntau = sum(Ntau)-sum(tau_error_converge);
vars = {'tau_grid','tau_path_wel','tau_path_wel_consum'};
for i = 1:length(vars)
    eval([vars{i}, ' = ', vars{i}, '(tau_error_converge == 0);']);
end

% find the optimal tax level
[max_wel,max_loc]=max(tau_path_wel_consum);
tau_opt = tau_grid(max_loc);
fprintf('Maximum welfare gains = %4.2f percent with tax rate = %4.2f percent\n',max_wel*100,tau_opt*100);

% save to plot with lower Q_a
save('tau_grid.mat', 'tau_grid');
save('tau_path_wel_consum.mat', 'tau_path_wel_consum');


%% Read data to plot the transitional dynamics under the optimal tax
% Define folder_opt path (update this path as needed)
folder_opt = folder_4;  % Change this to your actual folder_opt path
% paramters
Ntau = load(fullfile(folder_opt, 'Ntau.out'));
% grids
tau_grid = load(fullfile(folder_opt, 'tau_grid.out'));
tau_grid = reshape(tau_grid, [Ntau, 1]);
% exogenous
tau_path_Q_a = load(fullfile(folder_opt, 'tau_path_Q_a.out'));
tau_path_Q_a = reshape(tau_path_Q_a, [Ntau, NT]);
tau_path_tau = load(fullfile(folder_opt, 'tau_path_tau.out'));
tau_path_tau = reshape(tau_path_tau, [Ntau, NT]);
% guess
tau_path_SDFs = load(fullfile(folder_opt, 'tau_path_SDFs.out'));
tau_path_SDFs = reshape(tau_path_SDFs, [Ntau, NT]);
tau_path_YY = load(fullfile(folder_opt, 'tau_path_YY.out'));
tau_path_YY = reshape(tau_path_YY, [Ntau, NT]);
% results
tau_path_AA = load(fullfile(folder_opt, 'tau_path_AA.out'));
tau_path_AA = reshape(tau_path_AA, [Ntau, NT]);
tau_path_r_a = load(fullfile(folder_opt, 'tau_path_r_a.out'));
tau_path_r_a = reshape(tau_path_r_a, [Ntau, NT]);
tau_path_WW = load(fullfile(folder_opt, 'tau_path_WW.out'));
tau_path_WW = reshape(tau_path_WW, [Ntau, NT]);
tau_path_NN = load(fullfile(folder_opt, 'tau_path_NN.out'));
tau_path_NN = reshape(tau_path_NN, [Ntau, NT]);
tau_path_CC = load(fullfile(folder_opt, 'tau_path_CC.out'));
tau_path_CC = reshape(tau_path_CC, [Ntau, NT]);
tau_path_II = load(fullfile(folder_opt, 'tau_path_II.out'));
tau_path_II = reshape(tau_path_II, [Ntau, NT]);
tau_path_LS = load(fullfile(folder_opt, 'tau_path_LS.out'));
tau_path_LS = reshape(tau_path_LS, [Ntau, NT]);
tau_path_share_top1 = load(fullfile(folder_opt, 'tau_path_share_top1.out'));
tau_path_share_top1 = reshape(tau_path_share_top1, [Ntau, NT]);
tau_path_share_top1_emp = load(fullfile(folder_opt, 'tau_path_share_top1_emp.out'));
tau_path_share_top1_emp = reshape(tau_path_share_top1_emp, [Ntau, NT]);
tau_path_share_auto = load(fullfile(folder_opt, 'tau_path_share_auto.out'));
tau_path_share_auto = reshape(tau_path_share_auto, [Ntau, NT]);
tau_path_markup_sw = load(fullfile(folder_opt, 'tau_path_markup_sw.out'));
tau_path_markup_sw = reshape(tau_path_markup_sw, [Ntau, NT]);
tau_path_markup_cw = load(fullfile(folder_opt, 'tau_path_markup_cw.out'));
tau_path_markup_cw = reshape(tau_path_markup_cw, [Ntau, NT]);
tau_path_markup_disp = load(fullfile(folder_opt, 'tau_path_markup_disp.out'));
tau_path_markup_disp = reshape(tau_path_markup_disp, [Ntau, NT]);
tau_path_error_YY = load(fullfile(folder_opt, 'tau_path_error_YY.out'));
tau_path_error_YY = reshape(tau_path_error_YY, [Ntau, NT]);
tau_path_error_WW = load(fullfile(folder_opt, 'tau_path_error_WW.out'));
tau_path_error_WW = reshape(tau_path_error_WW, [Ntau, NT]);
tau_path_error_q = load(fullfile(folder_opt, 'tau_path_error_q.out'));
tau_path_error_q = reshape(tau_path_error_q, [Ntau, NT]);
tau_path_TT = load(fullfile(folder_opt, 'tau_path_TT.out'));
tau_path_TT = reshape(tau_path_TT, [Ntau, NT]);
tau_path_LP = load(fullfile(folder_opt, 'tau_path_LP.out'));
tau_path_LP = reshape(tau_path_LP, [Ntau, NT]);
tau_path_wel = load(fullfile(folder_opt, 'tau_path_wel.out'));
tau_path_wel = reshape(tau_path_wel, [Ntau, NT]);
tau_path_U = load(fullfile(folder_opt, 'tau_path_U.out'));
tau_path_U = reshape(tau_path_U, [Ntau, NT]);
tau_path_wel_consum = load(fullfile(folder_opt, 'tau_path_wel_consum.out'));
tau_path_wel_consum = reshape(tau_path_wel_consum, [Ntau, NT]);



%% plot aggregate variables for the paper
% only pick the path under the optimal policy
[~,itau]=min(abs(tau_grid-tau_opt));
% only draw the points without erros
error_sum = tau_path_error_YY(itau,:) + tau_path_error_WW(itau,:) + tau_path_error_q(itau,:);
I = error_sum == 0;
I(NT_cut+1:end) = 0; % will not draw for t>NT_cut
% plot
close;
width = 600*2/3;
figure('Position', [0, 0, width*1.7, width*1.0]);
% tau_path_tau
subplot(2,3,1);
hold on;
plot(time(I),tau_path_tau(itau,I)*100,'-','Color','black','LineWidth',lwidth);
yline(tau_path_tau(1)*100, '-', 'Color', 'blue', 'LineWidth', lwidth-1); % Adding the horizontal line
title("robot tax $\tau$, (\%)",'FontSize',font_size,'Interpreter','latex');
xlabel("quarters",'Interpreter','latex');
xlim([min(time(I)),max(max(time(I)),min(time(I))+0.0001)]);  
ylim([-1,0]);  
grid on;
hold off;
% tau_path_CC
subplot(2,3,2);
hold on;
plot(time(I),tau_path_CC(itau,I),'-','Color','black','LineWidth',lwidth);
yline(tau_path_CC(1), '-', 'Color', 'blue', 'LineWidth', lwidth-1); % Adding the horizontal line
title("consumption",'FontSize',font_size,'Interpreter','latex');
xlabel("quarters",'Interpreter','latex');
xlim([min(time(I)),max(max(time(I)),min(time(I))+0.0001)]);  
grid on;
hold off;
% tau_path_NN
subplot(2,3,3);
hold on;
plot(time(I),tau_path_NN(itau,I),'-','Color','black','LineWidth',lwidth);
yline(tau_path_NN(1), '-', 'Color', 'blue', 'LineWidth', lwidth-1,'HandleVisibility','off'); % Adding the horizontal line
title("employment",'FontSize',font_size,'Interpreter','latex');
xlabel("quarters",'Interpreter','latex');
xlim([min(time(I)),max(max(time(I)),min(time(I))+0.0001)]);  
grid on;
hold off;
% YY/NN: labor productivity
subplot(2,3,4);
hold on;
plot(time(I),tau_path_LP(itau,I),'-','Color','black','LineWidth',lwidth);
yline(tau_path_LP(1), '-', 'Color', 'blue', 'LineWidth', lwidth-1); % Adding the horizontal line
title("labor productivity",'FontSize',font_size,'Interpreter','latex');
xlabel("quarters",'Interpreter','latex');
xlim([min(time(I)),max(max(time(I)),min(time(I))+0.0001)]);  
grid on;
hold off;
% tau_path_II
subplot(2,3,5);
hold on;
plot(time(I),tau_path_II(itau,I),'-','Color','black','LineWidth',lwidth);
yline(tau_path_II(1), '-', 'Color', 'blue', 'LineWidth', lwidth-1); % Adding the horizontal line
title("investment",'FontSize',font_size,'Interpreter','latex');
xlabel("quarters",'Interpreter','latex');
xlim([min(time(I)),max(max(time(I)),min(time(I))+0.0001)]);  
grid on;
hold off;
% tau_path_share_top1
subplot(2,3,6);
hold on;
plot(time(I),tau_path_share_top1(itau,I),'-','Color','black','LineWidth',lwidth);
plot(time(I),tau_path_share_top1_emp(itau,I),'--','Color','red','LineWidth',lwidth);
lgnd=legend('sales','employment','Interpreter','latex','Location','northeast','FontSize',font_size);
yline(tau_path_share_top1(1), '-', 'Color', 'blue', 'LineWidth', lwidth-1,'HandleVisibility','off'); % Adding the horizontal line
yline(tau_path_share_top1_emp(1), '-', 'Color', 'blue', 'LineWidth', lwidth-1,'HandleVisibility','off'); % Adding the horizontal line
set(lgnd,'color','none');
title("top 1\% share",'FontSize',font_size,'Interpreter','latex');
xlabel("quarters",'Interpreter','latex');
xlim([min(time(I)),max(max(time(I)),min(time(I))+0.0001)]);  
ylim([0.257,0.31]);  
grid on;
hold off;
% save
exportgraphics(gcf,'tau_path_moments_under_optiaml_tax.png','Resolution',400);
close;

