%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Model Replication Code for:
  Firooz, Hamid, Zheng Liu, and Yajie Wang.
  "Automation and the Rise of Superstar Firms."
  Journal of Monetary Economics (2025), Article 103733.

First created: May 20, 2021  
Last updated: April 27, 2025

For questions or comments, please contact: yajie.wang@missouri.edu.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[Licenses]
1. toolbox
    Portions of this code were copied and adapted from the source codes 
    accompanying the book:
       Fehr, H. & Kindermann, F. (2018).
       "Introduction to Computational Economics using Fortran."
       Oxford: Oxford University Press.

2. asa239
    Portions of this code use routines based on:
       B. Shea,
       "Algorithm AS 239: Chi-squared and Incomplete Gamma Integral,"
       Applied Statistics, Vol. 37, No. 3 (1988), pp. 466–473.

3. log_normal
    Portions of this code are based on:
       John Burkardt,
       *LOG_NORMAL_CDF* routines,
       Licensed under the GNU LGPL,
       Modified: 12 February 1999.


[Algorithm]
- A detailed description of the algorithm can be found in Online Appendix C.
- Link to the paper and online appendix:  
  https://www.sciencedirect.com/science/article/pii/S0304393225000042


[Running the Code]
1. Steps:
   a. Navigate (cd) to the folder of the file you want to run.  
   b. Execute "main.sh" in the terminal to compile and run the Fortran code.  
   c. All plotting codes have a ".m" suffix and should be run in MATLAB.

2. Notes:
   a. "main.sh" assumes you have installed "toolbox.f90" and "asa239.f90" in your library.  
      Alternatively, you can directly include these files when compiling "main.f90",  
      as demonstrated in the folder `6_eta_mfg_transition`.
      - "toolbox.f90" is available at: https://github.com/fabiankindermann/ce-fortran/
      - "asa239.f90" is available at: https://people.sc.fsu.edu/~jburkardt/f_src/asa239/asa239.html
   b. Compiler: GNU Fortran (GCC) 10.2.0.  
   c. MATLAB Version: R2021a.  
   d. Machine: MacBook Pro with Apple M1 Chip, macOS 15.1.1.


[Files]
1. 1_eta_mfg  
   - Baseline steady state (Table 2, Fig. 4).
   - Run "main.sh" to compile and execute.

2. 2_eta_mfg_ANratio_old  
   - Same as 1, but robot price increased by 40% to compute historical robot density (Table 2).
   - Run "main.sh" to compile and execute.

3. 3_eta_mfg_QaL  
   - Same as 1, but robot price decreased by 40% to plot firms' decision rules (Fig. 4).
   - Run "main.sh" to compile and execute.

4. 4_eta_mfg_QaL_plot  
   - Plot firms' decision rules (Fig. 4).  
   - Run "plot_main.m" in MATLAB to plot the results.

5. 5_eta_mfg_continuum_Qa  
   - Solve aggregate variables in steady state with varying Qa (Fig. 5).
   - Run "main.sh" to compile and execute.
   - Run "plot_Q_a.m" in MATLAB to plot the results.

6. 6_eta_mfg_transition  
   - Solve transition path (Fig. 6).  
   - Parallelized on the University of Rochester Cluster (Bluehive), using 20 cores.  
   - Submit "main.sb" in the cluster terminal to compile and execute.
   - Run "plot_path.m" in MATLAB to plot the results.

7. 7_robot_tax_continuum_tau  
   - Solve steady-state effects of taxing robots (Fig. 7).
   - Run "main.sh" to compile and execute.
   - Run "plot_tau.m" in MATLAB to plot the results.

8. 8_robot_tax_continuum_tau_transition
   - Find the optimal robot tax considering the transition path (Figure Appendix A.6, Fig. 8).  
   - The tax intervals are split into 5 separate files, allowing them to be run simultaneously on the cluster.
   - Parallelized on the University of Rochester Cluster (Bluehive), using 20 cores per job.
   - Submit the "main.sb" script in each folder via the cluster terminal to compile and execute.
   - After solving, run "plot_tax.m" in MATLAB to collect the results.

9. 9_robot_tax_continuum_tau_transition_lowerQa
   - Same as (8), but under a lower robot price scenario (Fig. 8).
   - The tax intervals are split into 11 separate files, allowing them to be run simultaneously on the cluster.
   - Parallelized on the University of Rochester Cluster (Bluehive), using 20 cores per job.
   - Submit the "main.sb" script in each folder via the cluster terminal to compile and execute.
   - After solving, run "plot_tax.m" in MATLAB to collect the results.

10. 10_plot_tax_transition_2Qa
    - Plot welfare effects under transition dynamics (Fig. 8).
    - Run "plot_tax.m" in MATLAB to plot the results.

11. 11_eta_mfg_0fixedcost_continuum_Qa
    - Solve aggregate variables with varying Qa without fixed costs (Figure Appendix A.3).
    - Run "main.sh" to compile and execute.
    - Run "plot_Q_a.m" in MATLAB to plot the results.

12. 12_eta_mfg_CES
    - Solve steady state under CES (Table Appendix A.4).
    - Run "main.sh" to compile and execute.

13. 13_eta_mfg_CES_ANratio_old: 
    - Same as 12, but robot price increased by 40% to compute historical robot density (Table Appendix A.4).
    - Run "main.sh" to compile and execute.

14. 14_eta_mfg_CES_continuum_Qa
    - Solve aggregate variables with varying Qa under CES (Figure Appendix A.4).
    - Run "main.sh" to compile and execute.
    - Run "plot_Q_a.m" in MATLAB to plot the results.

15. 15_robot_tax_CES_continuum_tau
    - Solve steady-state effects of taxing robots under CES (Figure Appendix A.5).
    - Run "main.sh" to compile and execute.
    - Run "plot_tau.m" in MATLAB to plot the results.

16. 16_eta_mfg_mua
    - Solve steady state with calibrated mean fixed cost of automation (Table Appendix D.1, Table Appendix D.2).
    - Run "main.sh" to compile and execute.

17. 17_eta_mfg_mua_ANratio_old
    - Same as 16, but robot price increased by 40% to compute historical robot density (Table Appendix D.1, Table Appendix D.2). 
    - Run "main.sh" to compile and execute.

18. 18_eta_mfg_mua_continuum_Qa
    - Solve aggregate variables in the steady state with varying Qa with calibrated fixed costs (Figure Appendix D.1).
    - Run "main.sh" to compile and execute.
    - Run "plot_Q_a.m" in MATLAB to plot the results.


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

