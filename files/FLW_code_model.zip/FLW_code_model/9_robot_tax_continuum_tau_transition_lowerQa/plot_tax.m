%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Model Replication Code
%
% Paper:
%   Firooz, Hamid, Zheng Liu, and Yajie Wang,
%   "Automation and the Rise of Superstar Firms,"
%   Journal of Monetary Economics (2025), Article 103733.
%
% First created: May 20, 2021
% Last updated:  April 27, 2025
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

close all
clear;
clc;

format compact
    
% Parameters

% Plot options
lwidth = 1.5;
circle_size = 20;
font_size = 13;
color_3z = ['b','k','r'];
color2 = ['k','r'];
linS = {'-','-.','o'}; % line style

% the benchmark level of tau
xx_tau = 0;

% Plot the first NT_cut period
NT_cut = 100;

% directory
folder_main = '.';
folder_1 = fullfile(folder_main,'9a_robot_tax_continuum_tau_transition_lowQa_m0d01125');
folder_2 = fullfile(folder_main,'9b_robot_tax_continuum_tau_transition_lowQa_m0d010875');
folder_3 = fullfile(folder_main,'9c_robot_tax_continuum_tau_transition_lowQa_m0d0105');
folder_4 = fullfile(folder_main,'9d_robot_tax_continuum_tau_transition_lowQa_m0d01');
folder_5 = fullfile(folder_main,'9e_robot_tax_continuum_tau_transition_lowQa_m0d01tom0d009433');
folder_6 = fullfile(folder_main,'9f_robot_tax_continuum_tau_transition_lowQa_m0d008867tom0d0083');
folder_7 = fullfile(folder_main,'9g_robot_tax_continuum_tau_transition_lowQa_m0d007733tom0d007167');
folder_8 = fullfile(folder_main,'9h_robot_tax_continuum_tau_transition_lowQa_m0d0066tom0d006033');
folder_9 = fullfile(folder_main,'9i_robot_tax_continuum_tau_transition_lowQa_m0d005467tom0d0051');
folder_10 = fullfile(folder_main,'9j_robot_tax_continuum_tau_transition_lowQa_m0d005tomd0002');
folder_11 = fullfile(folder_main,'9k_robot_tax_continuum_tau_transition_lowQa_0to0d005');

% paramters
NT = load(fullfile(folder_1,'NT.out'));
time = 1:NT; % x axis

%% Read welfare data from all folders
% Define the list of folders and variable names to load and append
folders = {folder_1, folder_2, folder_3, folder_4, folder_5, ...
    folder_6, folder_7, folder_8, folder_9, folder_10, folder_11};
vars = {'Ntau', 'tau_grid', 'tau_error_converge', 'tau_path_wel', 'tau_path_wel_consum'};

% Load the initial variables from folder_1 and ensure compatibility
for i = 1:length(vars)
    filename = fullfile(folders{1}, [vars{i}, '.out']);
    eval([vars{i}, ' = load(filename);']);  % Load the variables into the workspace
    
    % If the variable is 'tau_path_wel' or 'tau_path_wel_consum', select the second element
    if strcmp(vars{i}, 'tau_path_wel') || strcmp(vars{i}, 'tau_path_wel_consum')
        eval([vars{i}, ' = ', vars{i}, '(2);']);
    end
    
    % Convert the variable to an array if it's a scalar (number)
    if isscalar(eval(vars{i}))
        eval([vars{i}, ' = ', vars{i}, ' * ones(1, 1);']);  % Convert to a 1x1 array
    end
end

% Loop through the remaining folders (2 to 5) and append the variables
for j = 2:length(folders)
    for i = 1:length(vars)
        % Construct the filename for the current folder and variable
        filename = fullfile(folders{j}, [vars{i}, '.out']);
        
        % Check if the file exists before loading
        if exist(filename, 'file')
            % Load the data from the current folder into a temporary variable
            eval([vars{i}, '_tmp = load(filename);']);
            
            % If the variable is 'tau_path_wel' or 'tau_path_wel_consum', reshape and select the second column
            if strcmp(vars{i}, 'tau_path_wel') || strcmp(vars{i}, 'tau_path_wel_consum')
                % Use Ntau(j) to dynamically determine the number of rows
                eval([vars{i}, '_tmp = reshape(', vars{i}, '_tmp, Ntau(j), NT);']);
                % Select only the second column
                eval([vars{i}, '_tmp = ', vars{i}, '_tmp(:, 2).'';']); % transpose
            end
            
            % Convert scalar to an array if necessary for consistency
            if isscalar(eval([vars{i}, '_tmp']))
                eval([vars{i}, '_tmp = ', vars{i}, '_tmp * ones(1, 1);']);  % Convert to a 1x1 array
            end
            
            % Ensure consistent dimensions for vertical concatenation
              
            
            % Append the data from the temporary variable to the original variable (vertically concatenate)
            eval([vars{i}, ' = [', vars{i}, ', ', vars{i}, '_tmp];']);
            %print(vars{i});
        else
            warning(['File not found: ', filename, ' in folder ', num2str(j)]);
        end
    end
end

% only keep the results with tau_error_converge == 0
Ntau = sum(Ntau)-sum(tau_error_converge);
vars = {'tau_grid','tau_path_wel','tau_path_wel_consum'};
for i = 1:length(vars)
    eval([vars{i}, ' = ', vars{i}, '(tau_error_converge == 0);']);
end

% find the optimal tax level
[max_wel,max_loc]=max(tau_path_wel_consum);
tau_opt = tau_grid(max_loc);
fprintf('Maximum welfare gains = %4.2f percent with tax rate = %4.2f percent\n',max_wel*100,tau_opt*100);

% save to plot with lower Q_a
save('tau_grid_lowerQa.mat', 'tau_grid');
save('tau_path_wel_consum_lowerQa.mat', 'tau_path_wel_consum');

