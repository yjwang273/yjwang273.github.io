%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Model Replication Code
%
% Paper:
%   Firooz, Hamid, Zheng Liu, and Yajie Wang,
%   "Automation and the Rise of Superstar Firms,"
%   Journal of Monetary Economics (2025), Article 103733.
%
% First created: May 20, 2021
% Last updated:  April 27, 2025
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

close all
clear;
clc;

format compact
    
% Parameters

% Plot options
lwidth = 1.5;
circle_size = 20;
font_size = 13;
color_3z = ['b','k','r'];
color2 = ['k','r'];
linS = {'-','-.','o'}; % line style

% the benchmark level of tau
xx_tau = 0;

%% Read data
% grids
tau_grid = load('tau_grid.out');
Ntau = size(tau_grid);
tau_grid = reshape(tau_grid,[Ntau,1]);
% results
tau_r_a = load('tau_r_a.out');
tau_r_a = reshape(tau_r_a,[Ntau,1]);
tau_WW = load('tau_WW.out');
tau_WW = reshape(tau_WW,[Ntau,1]);
tau_YY = load('tau_YY.out');
tau_YY = reshape(tau_YY,[Ntau,1]);
tau_AA = load('tau_AA.out');
tau_AA = reshape(tau_AA,[Ntau,1]);
tau_NN = load('tau_NN.out');
tau_NN = reshape(tau_NN,[Ntau,1]);
tau_CC = load('tau_CC.out');
tau_CC = reshape(tau_CC,[Ntau,1]);
tau_II = load('tau_II.out');
tau_II = reshape(tau_II,[Ntau,1]);
tau_LS = load('tau_LS.out');
tau_LS = reshape(tau_LS,[Ntau,1]);
tau_share_top1 = load('tau_share_top1.out');
tau_share_top1 = reshape(tau_share_top1,[Ntau,1]);
tau_share_top1_emp = load('tau_share_top1_emp.out');
tau_share_top1_emp = reshape(tau_share_top1_emp,[Ntau,1]);
tau_share_auto = load('tau_share_auto.out');
tau_share_auto = reshape(tau_share_auto,[Ntau,1]);
tau_markup_sw = load('tau_markup_sw.out');
tau_markup_sw = reshape(tau_markup_sw,[Ntau,1]);
tau_markup_cw = load('tau_markup_cw.out');
tau_markup_cw = reshape(tau_markup_cw,[Ntau,1]);
tau_markup_disp = load('tau_markup_disp.out');
tau_markup_disp = reshape(tau_markup_disp,[Ntau,1]);
tau_error_YY = load('tau_error_YY.out');
tau_error_YY = reshape(tau_error_YY,[Ntau,1]);
tau_error_WW = load('tau_error_WW.out');
tau_error_WW = reshape(tau_error_WW,[Ntau,1]);
tau_error_q = zeros(size(tau_error_WW));
tau_TT = load('tau_TT.out');
tau_TT = reshape(tau_TT,[Ntau,1]);
tau_wel = load('tau_wel.out');
tau_wel = reshape(tau_wel,[Ntau,1]);
tau_wel_consum = load('tau_wel_consum.out');
tau_wel_consum = reshape(tau_wel_consum,[Ntau,1]);
tau_LP = load('tau_LP.out');
tau_LP = reshape(tau_LP,[Ntau,1]);


%% plot aggregate variables for the paper
% only draw the points without erros
error_sum = tau_error_YY + tau_error_WW + tau_error_q;
I = error_sum == 0;
%xx_tau = min(tau_grid(tau_grid>=50));
% plot
close;
width = 600*2/3;
figure('Position', [0, 0, width*1.7, width*1.0]);
% tau_share_auto
subplot(2,3,1);
hold on;
plot(tau_grid(I),tau_share_auto(I),'-','Color','black','LineWidth',lwidth);
xline(xx_tau,'blue');
title("fraction of firms that automate",'FontSize',font_size,'Interpreter','latex');
xlabel("$\tau$",'Interpreter','latex');
xlim([min(tau_grid),max(max(tau_grid),min(tau_grid)+0.0001)]);  
grid on;
hold off;
% tau_share_top1
subplot(2,3,2);
hold on;
plot(tau_grid(I),tau_share_top1(I),'-','Color','black','LineWidth',lwidth);
plot(tau_grid(I),tau_share_top1_emp(I),'--','Color','red','LineWidth',lwidth);
xline(xx_tau,'blue');
lgnd=legend('sales','employment','Interpreter','latex','Location','northeast');
set(lgnd,'Interpreter','latex','FontSize',font_size,'color','white');
title("share of top 1\% firms",'FontSize',font_size,'Interpreter','latex');
xlabel("$\tau$",'Interpreter','latex');
xlim([min(tau_grid),max(max(tau_grid),min(tau_grid)+0.0001)]);  
ylim([0.3,0.53]);  
grid on;
hold off;
% tau_markup_sw & tau_markup_cw
subplot(2,3,3);
hold on;
plot(tau_grid(I),tau_markup_sw(I),'-','Color','black','LineWidth',lwidth);
plot(tau_grid(I),tau_markup_cw(I),'--','Color','red','LineWidth',lwidth);
xline(xx_tau,'blue');
lgnd=legend('sales-weighted','cost-weighted');
set(lgnd,'Interpreter','latex','FontSize',font_size,'Location','northeast','color','white');
title("average markup",'FontSize',font_size,'Interpreter','latex');
xlabel("$\tau$",'Interpreter','latex');
xlim([min(tau_grid),max(max(tau_grid),min(tau_grid)+0.0001)]);  
ylim([1.15,1.175]);  
grid on;
hold off;
% tau_NN
subplot(2,3,4);
hold on;
plot(tau_grid(I),tau_NN(I),'-','Color','black','LineWidth',lwidth);
xline(xx_tau,'blue');
title("employment",'FontSize',font_size,'Interpreter','latex');
xlabel("$\tau$",'Interpreter','latex');
xlim([min(tau_grid),max(max(tau_grid),min(tau_grid)+0.0001)]);  
grid on;
hold off;
% tau_LP
subplot(2,3,5);
hold on;
plot(tau_grid(I),tau_LP(I),'-','Color','black','LineWidth',lwidth);
xline(xx_tau,'blue');
title("labor productivity",'FontSize',font_size,'Interpreter','latex');
xlabel("$\tau$",'Interpreter','latex');
xlim([min(tau_grid),max(max(tau_grid),min(tau_grid)+0.0001)]);  
grid on;
hold off;
% tau_wel
subplot(2,3,6);
hold on;
plot(tau_grid(I),tau_wel_consum(I),'-','Color','black','LineWidth',lwidth);
xline(xx_tau,'blue');
title("welfare gains",'FontSize',font_size,'Interpreter','latex');
xlabel("$\tau$",'Interpreter','latex');
xlim([min(tau_grid),max(max(tau_grid),min(tau_grid)+0.0001)]);  
grid on;
hold off;
% save
%saveas(gcf,'tau_moments.png');
exportgraphics(gcf,'tau_moments_CES_paper.png','Resolution',300);
close;


%% optiaml tax rate
[max_wel,max_loc]=max(tau_wel_consum);
fprintf('Maximum welfare gains = %4.2f percent with tax rate = %4.2f percent\n',max_wel*100,tau_grid(max_loc)*100);
